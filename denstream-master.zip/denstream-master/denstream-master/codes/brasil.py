import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from DenStream import *

train = pd.read_csv("./denstream-master/input/brasil.csv",header=None,sep = ';',usecols =[0,1],skiprows =1)
#stream = pd.read_csv("./denstream-master/input/stream.csv", header=None)
#print("train/stream shape is:", train.shape, stream.shape)
print("train shape is:", train.shape)

#train_label = pd.read_csv("./denstream-master/input/train_label.csv", header=None)
#stream_label = pd.read_csv("./denstream-master/input/stream_label.csv", header=None)
#print("train/stream label shape is:", train_label.shape, stream_label.shape)
print(train)

fig = plt.figure(figsize=(9, 6))
plt.plot(train[0], train[1], ".b", markersize=15)
#plt.plot(train_label, ".r", markersize=15)

#plt.plot(stream[0], stream[1], ".r", markersize=15)

plt.grid()
plt.show()

clusterer = DenStream(lambd=0.1, eps=1.5, beta=0.5, mu=3)
y = clusterer.fit_predict(train)

cluster_center = []
cluster_radius = []
for cluster in clusterer.p_micro_clusters:
     
    cluster_center.append(cluster.center())
    cluster_radius.append(cluster.radius())

cluster_center = np.array(cluster_center)
cluster_radius = np.array(cluster_radius)
print(cluster_center,cluster_radius)
#print(cluster_center.shape, cluster_radius.shape)

# visualize
fig, ax = plt.subplots(figsize=(12,8))
plt.plot(train[0], train[1], ".b", markersize=6)
plt.plot(cluster_center[:, 0], cluster_center[:, 1], ".r", markersize=15)
for idx in range(len(cluster_center)):
    circle = plt.Circle((cluster_center[idx, 0], cluster_center[idx, 1]), cluster_radius[idx], color='r', fill=False, lw=2)
    ax.add_artist(circle)
plt.grid()
plt.show()

for i_x, i_y in zip(train[0], train[1]):
    print(i_x, i_y)